# Auditoría del proyecto v1.4.1-a

Añade el módulo interno de auditoría del proyecto.

## Uso

Copiar las carpetas `modules/` y `scripts/` en la raíz del proyecto.

Después ejecutar:

```bash
py scripts/instalar_auditoria.py
```

Luego:

```bash
py main.py
```

Debe aparecer:

```text
7. Auditoría del proyecto
```

La auditoría genera resultados en:

```text
Resultados_Auditoria/YYYY-MM-DD_HH-MM-SS/
```

Incluye:

- `Auditoria_Proyecto_v1.4.1-a.docx`
- `Resumen_Auditoria.txt`
