# v1.4.1-a

- Añadida base del módulo de auditoría.
