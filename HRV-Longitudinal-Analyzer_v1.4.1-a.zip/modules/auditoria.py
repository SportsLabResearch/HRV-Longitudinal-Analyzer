from pathlib import Path

def ejecutar_auditoria_proyecto():
    out=Path('Resultados_Auditoria')/'Auditoria_Proyecto'
    out.mkdir(parents=True,exist_ok=True)
    print('AUDITORÍA DEL PROYECTO')
    print('Generando informes...')
    return out
